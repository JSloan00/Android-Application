package com.zybooks.weighttrackapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class CreateAccountActivity extends AppCompatActivity {

    EditText username, password, repassword;
    Button buttonSignUp;
    DBHelper DB;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_account);

        username = (EditText) findViewById(R.id.username1);
        password = (EditText) findViewById(R.id.password1);
        repassword = (EditText) findViewById(R.id.repassword);
        buttonSignUp = findViewById(R.id.buttonSignUp);
        DB = new DBHelper(this);

        buttonSignUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String user = username.getText().toString();
                String pass = password.getText().toString();
                String repass = repassword.getText().toString();

                if(TextUtils.isEmpty(user) || TextUtils.isEmpty(pass) || TextUtils.isEmpty(repass)) {
                    Toast.makeText(CreateAccountActivity.this, "All fields required!", Toast.LENGTH_SHORT).show();
                }
                else {
                    if(pass.equals(repass)) {
                        Boolean checkuser = DB.checkUsername(user);
                        if(checkuser == false) {
                            Boolean insert = DB.insertData(user, pass);
                            if(insert ==true) {
                                Toast.makeText(CreateAccountActivity.this, "Registered successfully", Toast.LENGTH_SHORT).show();
                                Intent intent1 = new Intent(getApplicationContext(), HomepageActivity.class);
                                startActivity(intent1);
                            } else {
                                Toast.makeText(CreateAccountActivity.this, "Registration failed", Toast.LENGTH_SHORT).show();
                            }
                        } else {
                            Toast.makeText(CreateAccountActivity.this, "User already exists", Toast.LENGTH_SHORT).show();
                        }
                    }else {
                        Toast.makeText(CreateAccountActivity.this, "Passwords do not match", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });


    }


}
