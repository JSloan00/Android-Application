package com.zybooks.weighttrackapp;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;

public class HomepageActivity extends AppCompatActivity {

    EditText newWeight, newDate;
    Button enterWeight;
    DBHelper DB1;

    static String PhoneNumHolder;
    ImageButton smsButton;
    AlertDialog AlertDialog = null;

    private static final int USER_PERMISSIONS_REQUEST_SEND_SMS = 0;
    private static boolean smsAuthorized = false;

    public static void AllowSendSMS() {
        smsAuthorized = true;
    }
    public static void DenySendSMS() {
        smsAuthorized = false;
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_homepage);

        smsButton = findViewById(R.id.smsNotification);
        newWeight = (EditText) findViewById(R.id.newWeight);
        enterWeight = (Button) findViewById(R.id.enterWeight);
        newDate = (EditText) findViewById(R.id.newDate);
        DB1 = new DBHelper(this);

        enterWeight.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String weight = newWeight.getText().toString();
                String date = newDate.getText().toString();

                if(TextUtils.isEmpty(weight) || TextUtils.isEmpty(date)) {
                    Toast.makeText(HomepageActivity.this, "Please enter weight and date", Toast.LENGTH_SHORT).show();
                } else {
                    Boolean insert = DB1.insertDataWeight(weight, date);
                    if(insert) {
                        Toast.makeText(HomepageActivity.this, "Weight added", Toast.LENGTH_SHORT).show();
                    }else{
                        Toast.makeText(HomepageActivity.this, "Weight failed to add", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });

        // Adding click listener to smsNotification
        smsButton.setOnClickListener(view -> {
            // Request sms permission for the device
            if (ContextCompat.checkSelfPermission(this,
                    android.Manifest.permission.SEND_SMS)
                    != PackageManager.PERMISSION_GRANTED) {

                if (ActivityCompat.shouldShowRequestPermissionRationale(this,
                        android.Manifest.permission.SEND_SMS)) {
                    Toast.makeText(this,"Device SMS Permission is Needed", Toast.LENGTH_LONG).show();
                } else {
                    ActivityCompat.requestPermissions(this,
                            new String[] {Manifest.permission.SEND_SMS},
                            USER_PERMISSIONS_REQUEST_SEND_SMS);
                }
            } else {
                Toast.makeText(this,"Device SMS Permission is Allowed", Toast.LENGTH_LONG).show();
            }
            // Open SMS Alert Dialog
            AlertDialog = AD_SMSNotification.doubleButton(this);
            AlertDialog.show();
        });
    }
    public static void SendSMSMessage(Context context) {
        String phoneNo = PhoneNumHolder;
        String smsMsg = "You have reached your goal weight!";

        // Evaluate AlertDialog permission to send SMS and ItemQtyValue value
        if (smsAuthorized) {
            try {
                SmsManager smsManager = SmsManager.getDefault();
                smsManager.sendTextMessage(phoneNo, null, smsMsg, null, null);
                Toast.makeText(context, "SMS Sent", Toast.LENGTH_LONG).show();
            } catch (Exception ex) {
                Toast.makeText(context, "Device Permission Denied", Toast.LENGTH_LONG).show();
                ex.printStackTrace();
            }
        } else {
            Toast.makeText(context, "App SMS Alert Disable", Toast.LENGTH_LONG).show();
        }
    }
}